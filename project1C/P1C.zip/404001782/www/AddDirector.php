<!DOCTYPE HTML>
<html>
    <title>CS143 Project 1C</title>
<body>
  
<!-- NAV BAR -->
  <nav style="display: inline block; max-width: 30%; float: left;">
      <ul><a href="/~cs143/AddMovie.php">Add Movie</a></ul>
      <ul><a href="/~cs143/AddActor.php">Add Actor or Director</a></ul>
      <ul><a href="/~cs143/AddMovieActor.php">Add Movie/Actor</a></ul>
      <ul><a href="/~cs143/AddMovieDirector.php">Add Movie/Director</a></ul>
      <ul><a href="/~cs143/SearchActorMovie.php">Search Actor/Movie</a></ul>
      <ul><a href="/~cs143/ShowActor.php">Show Actor</a></ul>
      <ul><a href="/~cs143/ShowMovie.php">Show Movie</a></ul>
  </nav>
<!-- END NAV BAR -->

<div style="display: inline block; padding-left: 30%;">
  <!-- CODE GOES HERE -->
    <h1>CS 143 Database Search</h1>
    <h2>Add Director</h2>
  
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac tortor dolor.</p>
  
  </body>
  </html>
</div>