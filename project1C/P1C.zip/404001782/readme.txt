For the project we divided up the work and collaborated using github.
